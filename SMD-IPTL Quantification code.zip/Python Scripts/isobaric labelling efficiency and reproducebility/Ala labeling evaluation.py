def extract_and_return_modified_peptide_list (*file_route_and_file_name):
    print ('evaluating labeling efficiency')
    import csv
#importing csv module
    import re
#importing re module for removing the numbers in row of .csv file
    Area_row_name = input ('Please enter Area Ma-LysC-Yeast-pep-with-Ac-Ala-PNP-plusX')
    Ala_channel = input ('Please enter the channel of Ala 113.05,114.05,115.05 or 116.05')
    Ala_channel_name = input ('Please enter the channel name of Ala_plus0_labeled,Ala_plus1_labeled,Ala_plus2_labeled or Ala_plus3_labeled')
    
    space = ''
    
    modified_peptides_list = {}
    how_many_row_checked = 0
    for each_protein_peptides_csv_file in file_route_and_file_name:
        file_route = each_protein_peptides_csv_file [0]
        file_name = each_protein_peptides_csv_file [1]
        with open (file_route + file_name) as csvfile:
            reader = csv.DictReader (csvfile)
#calling the csv reader and read the csv file
    
            for row in reader:

                how_many_row_checked = how_many_row_checked +1
                
                scan_number = row['Scan']
                if scan_number == '':
                    break
                else:
                    temp_peptide_sequence = str (row['Peptide'])
                    measured_peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))[1:-1]
                    if measured_peptide not in modified_peptides_list:
                        modified_peptides_list [measured_peptide] = {}
                    
                    '''print (measured_peptide)
                    print (temp_peptide_sequence)
                    print ('temp_peptide_sequence [-9:-3]',temp_peptide_sequence [-9:-3])
                    print ('Ala_channel',Ala_channel)'''
                    if temp_peptide_sequence [-9:-3] != Ala_channel:
                        if 'unmodified' not in modified_peptides_list [measured_peptide]:
                            modified_peptides_list [measured_peptide]['unmodified'] = round (float (row [Area_row_name]),2)
                        else:
                            modified_peptides_list [measured_peptide]['unmodified'] = modified_peptides_list [measured_peptide]['unmodified'] + round (float (row [Area_row_name]),2)

                    elif temp_peptide_sequence [-9:-3] == Ala_channel:
                        
                        if Ala_channel_name not in modified_peptides_list [measured_peptide]:
                            
                            modified_peptides_list [measured_peptide][Ala_channel_name] = round (float (row [Area_row_name]),2)
                        else:
                            modified_peptides_list [measured_peptide][Ala_channel_name] = modified_peptides_list [measured_peptide][Ala_channel_name] + round (float (row [Area_row_name]),2)
                            
                                       
                '''print (modified_peptides_list)
                print ('************************************************')'''
    for each_peptide_sequence in modified_peptides_list.keys():
        if 'unmodified' not in modified_peptides_list [each_peptide_sequence]:
            modified_peptides_list [each_peptide_sequence]['unmodified'] = 0
        if Ala_channel_name not in modified_peptides_list [each_peptide_sequence]:
            modified_peptides_list [each_peptide_sequence][Ala_channel_name] = 0
        
    '''print (modified_peptides_list)
    print ('************************************************')'''

    import csv

    write_by_rows = [['peptide_sequence','sum_all_peptide_modifications_area',Ala_channel_name + '_ratio',Ala_channel_name + '_area','unmodified_ratio','unmodified_area']]

    for each_peptide_sequence in modified_peptides_list.keys():

        sum_each_peptide_sequence_modifications = round(modified_peptides_list [each_peptide_sequence][Ala_channel_name] + modified_peptides_list [each_peptide_sequence]['unmodified'])

        if sum_each_peptide_sequence_modifications == 0 or modified_peptides_list [each_peptide_sequence][Ala_channel_name] == 0:
            continue
        else:
            new_line = []

            new_line.append (str (each_peptide_sequence))
            new_line.append (str (sum_each_peptide_sequence_modifications))
            new_line.append (str (round (modified_peptides_list [each_peptide_sequence][Ala_channel_name]/sum_each_peptide_sequence_modifications,2)))
            new_line.append (str (modified_peptides_list [each_peptide_sequence][Ala_channel_name]))
            new_line.append (str (round (modified_peptides_list [each_peptide_sequence]['unmodified']/sum_each_peptide_sequence_modifications,2)))
            new_line.append (str (modified_peptides_list [each_peptide_sequence]['unmodified']))

        write_by_rows.append (new_line)
           
    out_putfile = open (file_path + 'modification_evaluation.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    out_putfile.close()
    print ('how_many_row_checked',how_many_row_checked)       
    return modified_peptides_list

file_path ='G:\\Desktop\\IPTL\\Manuscript preparation\\Fig. 3 isolation window and reproducebility\\Ma-Yeast with 4-plex Ac-Ala-PNP\\Ma-Yeast with 4-plex Ac-Ala-plus0\\'
test_file_1 = 'Ma-Yeast with 4-plex Ac-Ala-plus0.csv'

'''test_file_2 = 'protein-peptides11-20.csv'
test_file_3 = 'protein-peptides11-22.csv'
test_file_4 = 'protein-peptides21-22.csv

all_uni_peps = combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2])
print ('all_uni_peps',len (all_uni_peps),all_uni_peps)

all_uni_peps_test_derepli = combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3])
print ('all_uni_peps_test_derepli',len (all_uni_peps_test_derepli),all_uni_peps_test_derepli)'''

'''all_uni_peps = extract_and_return_uni_pep_list ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3])
print ('all_uni_peps',len (all_uni_peps),all_uni_peps)'''

maleylation_evaluation = extract_and_return_modified_peptide_list ([file_path,test_file_1])

