def extract_and_return_modified_peptide_list (*file_route_and_file_name):
    print ('evaluating labeling efficiency')
    import csv
#importing csv module
    import re
#importing re module for removing the numbers in row of .csv file
    Area_row_name = input ('Please enter Area Male-LysC-Yeast-tubeX')
    
    space = ''
    
    modified_peptides_list = {}
    
    for each_protein_peptides_csv_file in file_route_and_file_name:
        file_route = each_protein_peptides_csv_file [0]
        file_name = each_protein_peptides_csv_file [1]
        with open (file_route + file_name) as csvfile:
            reader = csv.DictReader (csvfile)
#calling the csv reader and read the csv file
    
            for row in reader:
                scan_number = row['Scan']
                if scan_number == '':
                    break
                else:
                    temp_peptide_sequence = str (row['Peptide'])
                    measured_peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))[1:-1]
                    if measured_peptide not in modified_peptides_list:
                        modified_peptides_list [measured_peptide] = {}
                    
                    '''print (measured_peptide)
                    print (temp_peptide_sequence)
                    print (temp_peptide_sequence [3:11])
                    print (temp_peptide_sequence [-10:-2])'''
                    if temp_peptide_sequence [3:11] == '(+98.00)' and temp_peptide_sequence [-10:-2] != '(+98.00)':
                        if 'single_N_maleylation' not in modified_peptides_list [measured_peptide]:
                            modified_peptides_list [measured_peptide]['single_N_maleylation'] = round (float (row [Area_row_name]),2)
                        else:
                            modified_peptides_list [measured_peptide]['single_N_maleylation'] = modified_peptides_list [measured_peptide]['single_N_maleylation'] + round (float (row [Area_row_name]),2)

                    elif temp_peptide_sequence [3:11] == '(+98.00)' and temp_peptide_sequence [-10:-2] == '(+98.00)':
                        
                        if 'double_modified' not in modified_peptides_list [measured_peptide]:
                            
                            modified_peptides_list [measured_peptide]['double_modified'] = round (float (row [Area_row_name]),2)
                        else:
                            modified_peptides_list [measured_peptide]['double_modified'] = modified_peptides_list [measured_peptide]['double_modified'] + round (float (row [Area_row_name]),2)
                            
                    elif temp_peptide_sequence [3:11] != '(+98.00)' and temp_peptide_sequence [-10:-2] != '(+98.00)':
                        if 'unmodified' not in modified_peptides_list [measured_peptide]:
                            modified_peptides_list [measured_peptide]['unmodified'] = round (float (row [Area_row_name]),2)
                        else:
                            modified_peptides_list [measured_peptide]['unmodified'] = modified_peptides_list [measured_peptide]['unmodified'] + round (float (row [Area_row_name]),2)
                            
                    elif temp_peptide_sequence [3:11] != '(+98.00)' and temp_peptide_sequence [-10:-2] == '(+98.00)':
                        if 'single_C_maleylation' not in modified_peptides_list [measured_peptide]:
                            modified_peptides_list [measured_peptide]['single_C_maleylation'] = round (float (row [Area_row_name]),2)
                        else:
                            modified_peptides_list [measured_peptide]['single_C_maleylation'] = modified_peptides_list [measured_peptide]['single_C_maleylation'] + round (float (row [Area_row_name]),2)
                    
            '''print (modified_peptides_list)
            print ('************************************************')'''
    for each_peptide_sequence in modified_peptides_list.keys():
        if 'single_N_maleylation' not in modified_peptides_list [each_peptide_sequence]:
            modified_peptides_list [each_peptide_sequence]['single_N_maleylation'] = 0
        if 'double_modified' not in modified_peptides_list [each_peptide_sequence]:
            modified_peptides_list [each_peptide_sequence]['double_modified'] = 0
        if 'unmodified' not in modified_peptides_list [each_peptide_sequence]:
            modified_peptides_list [each_peptide_sequence]['unmodified'] = 0
        if 'single_C_maleylation' not in modified_peptides_list [each_peptide_sequence]:
            modified_peptides_list [each_peptide_sequence]['single_C_maleylation'] = 0
        '''print (modified_peptides_list)
        print ('************************************************')'''

    import csv

    write_by_rows = [['peptide_sequence','sum_all_peptide_modifications_area','single_N_maleylation_ratio','single_N_maleylation_area','double_modified_ratio','double_modified_area','unmodified_ratio','unmodified_area','single_C_maleylation_ratio','single_C_maleylation_area']]

    for each_peptide_sequence in modified_peptides_list.keys():

        sum_each_peptide_sequence_modifications = round(modified_peptides_list [each_peptide_sequence]['single_N_maleylation'] + modified_peptides_list [each_peptide_sequence]['double_modified'] + modified_peptides_list [each_peptide_sequence]['unmodified'] + modified_peptides_list [each_peptide_sequence]['single_C_maleylation'])

        if sum_each_peptide_sequence_modifications != 0:
            new_line = []

            new_line.append (str (each_peptide_sequence))
            new_line.append (str (sum_each_peptide_sequence_modifications))
            new_line.append (str (round (modified_peptides_list [each_peptide_sequence]['single_N_maleylation']/sum_each_peptide_sequence_modifications,2)))
            new_line.append (str (modified_peptides_list [each_peptide_sequence]['single_N_maleylation']))
            new_line.append (str (round (modified_peptides_list [each_peptide_sequence]['double_modified']/sum_each_peptide_sequence_modifications,2)))
            new_line.append (str (modified_peptides_list [each_peptide_sequence]['double_modified']))
            new_line.append (str (round (modified_peptides_list [each_peptide_sequence]['unmodified']/sum_each_peptide_sequence_modifications,2)))
            new_line.append (str (modified_peptides_list [each_peptide_sequence]['unmodified']))
            new_line.append (str (round (modified_peptides_list [each_peptide_sequence]['single_C_maleylation']/sum_each_peptide_sequence_modifications,2)))
            new_line.append (str (modified_peptides_list [each_peptide_sequence]['single_C_maleylation']))

        write_by_rows.append (new_line)
           
    out_putfile = open (file_path + 'modification_evaluation.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    out_putfile.close()
            
    return modified_peptides_list

file_path ='G:\\Desktop\\IPTL\\Manuscript preparation\\Fig. 3 isolation window and reproducebility\\Maleylation on LysC Yeast reproducibility\\Mal on LysC tube1\\'
test_file_1 = 'Male on LysC Yeast pep tube1.csv'

'''test_file_2 = 'protein-peptides11-20.csv'
test_file_3 = 'protein-peptides11-22.csv'
test_file_4 = 'protein-peptides21-22.csv

all_uni_peps = combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2])
print ('all_uni_peps',len (all_uni_peps),all_uni_peps)

all_uni_peps_test_derepli = combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3])
print ('all_uni_peps_test_derepli',len (all_uni_peps_test_derepli),all_uni_peps_test_derepli)'''

'''all_uni_peps = extract_and_return_uni_pep_list ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3])
print ('all_uni_peps',len (all_uni_peps),all_uni_peps)'''

maleylation_evaluation = extract_and_return_modified_peptide_list ([file_path,test_file_1])

