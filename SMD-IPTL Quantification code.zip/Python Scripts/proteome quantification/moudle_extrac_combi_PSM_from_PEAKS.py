import csv
#importing csv module
import re
#importing re module for removing the numbers in row of peptide from the PEAKS PSM


def extractor_producer_from_PSM_of_PEAKS (entered_file_route,entered_file_name):
#prepare the unique peptides list and these files exported from PEAKS result (supporting peptide).If more channels need to be added, only need changes the file_path and test_file
    import Extract_unique_peptides_return_uni_pep_list
    file_path = 'C:\\Users\\63272\\Desktop\\IPTL data moudle June212019\\Ac-Cys-Ma-Yesat-Ac-Ala-12to13C-Ac-Cys-1to1-NW_PEAKS_15\\'
    test_file_1 = 'protein-peptides-Cys+1-Ala.csv'
    test_file_2 = 'protein-peptides-Cys-Ala+1.csv'
    unique_peptides = Extract_unique_peptides_return_uni_pep_list.combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2])

    file_route = entered_file_route
    file_name = entered_file_name
    space = ''
    #rowcnt = 0
    headers = ['scan_number','m_over_z','retention_time', 'peptide', 'mass','charge_states','logp','length','ppm','area','protein',]
    rows = []
    de_replicates = []
#defining file route, variable, header of csv
    
    with open (file_route + file_name) as csvfile:
        reader = csv.DictReader (csvfile)
#calling the csv reader and read the target csv file
    
        for row in reader:
            #rowcnt += 1
            #if rowcnt > 10:
                #break
            #rowcnt is used for testing code for several rows
            scan_number = row['Scan']
            peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))
            if scan_number == '' or peptide not in unique_peptides:
                break
            else:
                scan_number = int (row['Scan'])
                m_over_z = round (float (row['m/z']),4)
                retention_time = round (float (row['RT'])*60,4)
                peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))
#the are some numbers in the row of peptide. using the re.findall to remove the numbers and using the space.join to combine them
                mass = round (float (row['Mass']),4)
                charge_states = int (row['Z'])
                logp = round (float (row['-10lgP']),2)
                length = int (row['Length'])
                ppm = round (float (row['ppm']),4)
                area = row['Area']
                protein = row['Accession']
#relating the new rows with the rows in original csv
        
                if ({'scan_number':scan_number,'peptide':peptide}) in de_replicates:
                    continue
#using the scan number and peptide as the indictor to determine the spectrum is replicate or not
                else:
                    rows.append ({'scan_number':scan_number,'m_over_z':m_over_z,'retention_time':retention_time, 'peptide':peptide,'mass':mass,
                      'charge_states':charge_states,'logp':logp,'length':length,'ppm':ppm,'area':area,'protein':protein})
                    de_replicates.append ({'scan_number':scan_number,'peptide':peptide})
#add the 'row' to the defined list rows [] 

    return rows

def combining_extrac_csv_to_dict (*extracted_csvs):
    headers = ['scan_number','m_over_z','retention_time', 'peptide', 'mass','charge_states','logp','length','ppm','area','protein',]
    combined_rows = []
    for each_extracted_csv_row in extracted_csvs:
        combined_rows.extend (each_extracted_csv_row)
    import os
    output_route = os.getcwd()
    print (output_route)
    output_file = open (output_route + 'combined_derepli_csv.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    f_csv = csv.DictWriter(output_file, headers)
    f_csv.writeheader()
    f_csv.writerows(combined_rows)

    output_file.close()
