def normalize_ratio_for_spec (work_path,fragment_ions_matched_intens):

    ###Based on the theroretical ratio, calculating the normalize numeber
    desired_ratio = input ('please indicattes the desired sample ratio')
    normalize_number = 0
    for each_ratio_number in desired_ratio:
        normalize_number = normalize_number + int(each_ratio_number)

    ###For 4-plex labeled fragment ion, if any channel lost the signal, the one will be discarded. Here, defining the minimum number of macthed 4-plex labeled ion.
    ###If the spectrum has less matched 4-plex labeled, the spectrum will be marked as 'not counted'
    minimum_number_of_matched_ion_for_calculate_ratio = int (input ('please indicattes minimum number of matched ion for single spectrum'))
    
    file_path = work_path

    gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num = {}
    
    for each_scan_number in fragment_ions_matched_intens.keys():
        all_ion_name = []
        gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number] = []
        ion_name_match_four_plex_intensity = {}
        collect_four_intensities = []
        sum_four_intensities = []
        for each_frag_ion in fragment_ions_matched_intens [each_scan_number]:

            ### To exclude the y1 ions,the '-H2O' and '-NH3' ions. If the original 4-plex labeled fragment ions are needed, just skip these two row.
            if each_frag_ion [0][0:3] == 'y1_' or '-H2O' in each_frag_ion [0] or '-NH3' in each_frag_ion [0]:
                ###print (each_scan_number,each_frag_ion,'discarded')
                continue
            if each_frag_ion [0][0:3] == 'y1_' or '-H2O' in each_frag_ion [0] or '-NH3' in each_frag_ion [0]:
                print (each_scan_number,each_frag_ion,'Check point')
                
            if each_frag_ion [0][-5:] == '13C+0':

                all_ion_name.append (each_frag_ion [0][0:-6])
                ion_name_match_four_plex_intensity [each_frag_ion [0][0:-6]] =  []
                
                collect_four_intensities.append (float (each_frag_ion [3]))
                ion_name_match_four_plex_intensity[each_frag_ion [0][0:-6]].append (each_frag_ion)
                
            elif each_frag_ion [0][-5:] == '13C+1':
                collect_four_intensities.append (float (each_frag_ion [3]))
                ion_name_match_four_plex_intensity[each_frag_ion [0][0:-6]].append (each_frag_ion)
            elif each_frag_ion [0][-5:] == '13C+2':
                collect_four_intensities.append (float (each_frag_ion [3]))
                ion_name_match_four_plex_intensity[each_frag_ion [0][0:-6]].append (each_frag_ion)
            elif each_frag_ion [0][-5:] == '13C+3':
                
                collect_four_intensities.append (float (each_frag_ion [3]))
                ion_name_match_four_plex_intensity[each_frag_ion [0][0:-6]].append (each_frag_ion)
                ###The b ions and y ions has the complementary ratio. For keep the final ratio of y ions consist ratio of b ions, reversing the intensity order.
                if each_frag_ion [0][0:1] == 'y':
                    collect_four_intensities.reverse ()
                ion_name_match_four_plex_intensity [each_frag_ion [0][0:-6]].insert (0,collect_four_intensities)
               
                ###The '13C+3' is used as the end of every fragment ion. At the end of every fragment ion, the total intensity of that single fragment ion will be caculated.
                four_channels_total_intensity = 0
                for each_intensity in collect_four_intensities:
                    four_channels_total_intensity = four_channels_total_intensity + float (each_intensity)
                sum_four_intensities.append (four_channels_total_intensity)
                ion_name_match_four_plex_intensity [each_frag_ion [0][0:-6]].insert (1,sum_four_intensities)

                ###The calculated sum_four_intensities will be used to produce normalize number.
                ###For example, for 1515 theroretical ratio the sum_four_intensities/(1+5+1+5) is the normalize nuber which represent the intensity of '1'.
                normalized_four_intensities_ratio = []
                uncounted_channel_signal_loss = ['uncounted_due_to_channel_signal_loss',0,0,0]
                if 0 in collect_four_intensities:
                    ion_name_match_four_plex_intensity [each_frag_ion [0][0:-6]].insert (0,uncounted_channel_signal_loss)
                else:
                    for each_intensity in collect_four_intensities:
                        normalized_four_intensities_ratio.append (round (float (each_intensity)/(four_channels_total_intensity/normalize_number),2))
                    ion_name_match_four_plex_intensity [each_frag_ion [0][0:-6]].insert (0,normalized_four_intensities_ratio)
                
                collect_four_intensities = []
                sum_four_intensities = []
                                                 
            elif each_frag_ion [0][0:4] == 'spec':

                gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].append (ion_name_match_four_plex_intensity)
                
                gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].append (each_frag_ion)

        ###To determine which ions should be used for calculating ratio on the sacn level.If the precursor ion selection was bothered by 13C contribution, only the b1,2 and y1,2 will be used.
        number_of_match_ion = 0
        counted_matched_ions = []
        sum_intensity_spec_ratio = [0,0,0,0]
        normalized_spec_ratio = [0,0,0,0]
        
        if fragment_ions_matched_intens [each_scan_number][-1:][0][1][-1:][0][1] == 1:
        
            for each_kind_of_fragment_ion in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0].keys():
                if len (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0][each_kind_of_fragment_ion][0]) == 4:
                    number_of_match_ion = number_of_match_ion + 1
                    counted_matched_ions.append (each_kind_of_fragment_ion)
                    sum_intensity_spec_ratio [0] = sum_intensity_spec_ratio [0] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][0])
                    sum_intensity_spec_ratio [1] = sum_intensity_spec_ratio [1] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][1])
                    sum_intensity_spec_ratio [2] = sum_intensity_spec_ratio [2] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][2])
                    sum_intensity_spec_ratio [3] = sum_intensity_spec_ratio [3] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][3])
        elif fragment_ions_matched_intens [each_scan_number][-1:][0][1][-1:][0][1] == 0:
            for each_kind_of_fragment_ion in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0].keys():
                
                if len (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0][each_kind_of_fragment_ion][0]) == 4 and int (each_kind_of_fragment_ion.split ('_')[0][1:]) < 3:
                    number_of_match_ion = number_of_match_ion + 1
                    counted_matched_ions.append (each_kind_of_fragment_ion)

                    sum_intensity_spec_ratio [0] = sum_intensity_spec_ratio [0] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][0])
                    sum_intensity_spec_ratio [1] = sum_intensity_spec_ratio [1] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][1])
                    sum_intensity_spec_ratio [2] = sum_intensity_spec_ratio [2] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][2])
                    sum_intensity_spec_ratio [3] = sum_intensity_spec_ratio [3] + float (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number][0] [each_kind_of_fragment_ion][1][3])
            
        sum_intensity_spec_ratio [0] = round (sum_intensity_spec_ratio [0],4)
        sum_intensity_spec_ratio [1] = round (sum_intensity_spec_ratio [1],4)
        sum_intensity_spec_ratio [2] = round (sum_intensity_spec_ratio [2],4)
        sum_intensity_spec_ratio [3] = round (sum_intensity_spec_ratio [3],4)
        
        if number_of_match_ion >= minimum_number_of_matched_ion_for_calculate_ratio:
                
            spec_all_channel_total_intensity = 0
            for spec_each_channel_total_intensity in sum_intensity_spec_ratio:
                spec_all_channel_total_intensity = spec_all_channel_total_intensity + float (spec_each_channel_total_intensity)
            normalized_spec_ratio [0] = round (sum_intensity_spec_ratio [0]/(spec_all_channel_total_intensity/normalize_number),2)
            normalized_spec_ratio [1] = round (sum_intensity_spec_ratio [1]/(spec_all_channel_total_intensity/normalize_number),2)
            normalized_spec_ratio [2] = round (sum_intensity_spec_ratio [2]/(spec_all_channel_total_intensity/normalize_number),2)
            normalized_spec_ratio [3] = round (sum_intensity_spec_ratio [3]/(spec_all_channel_total_intensity/normalize_number),2)
            gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].insert (0,normalized_spec_ratio)
            gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].insert (1,sum_intensity_spec_ratio)
            gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].insert (2,counted_matched_ions)

        else:
            uncounted_too_less_matched_ion = ['uncounted_due_to_too_less_matched_ion',0,0,0]
            no_ion_was_used = ['no_ion_was_used']
            gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].insert (0,uncounted_too_less_matched_ion)
            gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].insert (1,sum_intensity_spec_ratio)
            gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num [each_scan_number].insert (2,counted_matched_ions)
                    
    output_file = open (file_path + 'Dict_all_fragment_ion_add_matched_intens_normalized_ratio.txt', 'w')
    output_file.write(str(gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num))
    output_file.close()
    
    ############################################
    import csv

    write_by_rows = [['scan_number','ion_name','normalized_ratio_frag_ion_level','every_channel_intensity__frag_ion_level','total_intensity_frag_ion_level','fragment_ion_mass','peptide', 'protein']]
    
    for each_scan_number in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num.keys():
        ###print (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number])
        
        new_line = [str (each_scan_number)]
        for each_fragment_ion_frag_ion_level in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3].keys():
            new_line.append (str (each_fragment_ion_frag_ion_level))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][0]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][1]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][2][0]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][3][2]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][9][1]))
            write_by_rows.append (new_line)

            new_line = [str (each_scan_number)]
       
    
    out_putfile = open (file_path + 'Fragment_ions_normalized_ratio_for_quik_check.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Fragment_ions_normalized_ratio_for_quik_check csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()
    

    ############################################
    import csv

    write_by_rows = [['scan_number','ion_name','nor_ratio_frag_ion_level_plus0','nor_ratio_frag_ion_level_plus1','nor_ratio_frag_ion_level_plus2','nor_ratio_frag_ion_level_plus3','every_channel_intensity__frag_ion_level','total_intensity_frag_ion_level','fragment_ion_mass','peptide', 'protein']]
    
    for each_scan_number in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num.keys():
        
        new_line = [str (each_scan_number)]
        for each_fragment_ion_frag_ion_level in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3].keys():
            
            new_line.append (str (each_fragment_ion_frag_ion_level))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][0][0]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][0][1]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][0][2]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][0][3]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][1]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][2][0]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][3][each_fragment_ion_frag_ion_level][3][2]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]))
            new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][9][1]))
            write_by_rows.append (new_line)

            new_line = [str (each_scan_number)]
       
    
    out_putfile = open (file_path + 'Fragment_ions_normalized_ratio_for_figure.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Fragment_ions_normalized_ratio_for_figure csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()
    
    ############################################
    import csv

    write_by_rows = [['scan_number','normalized_ratio','total_intensity_on_spec_level','counted_frag_ions','peptide', 'protein']]
    how_many_sacn_number_in_scan_csv = 0
    for each_scan_number in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num.keys():
        
        new_line = [str (each_scan_number)]
        new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][0]))
        new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1]))
        new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][2]))
        new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]))
        new_line.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][9][1]))
        write_by_rows.append (new_line)
           
    out_putfile = open (file_path + 'Every_spec_normalized_ratio_for_quik_check.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

    ##############################################
    write_by_rows_for_figure = [['scan_number','nor_ratio_Cys+0','nor_ratio_Cys+1','nor_ratio_Cys+2','nor_ratio_Cys+3','intensity_Cys+0','intensity_Cys+1','intensity_Cys+2','intensity_Cys+3','total_intensity','counted_frag_ions','peptide', 'protein']]
    
    for each_scan_number in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num.keys():
    
        new_line_figure = [str (each_scan_number)]
        if len (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][0]) == 4:
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][0][0]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][0][1]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][0][2]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][0][3]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1][0]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1][1]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1][2]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1][3]))
            new_line_figure.append (str (sum (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1])))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][2]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]))
            new_line_figure.append (str (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][9][1]))
        write_by_rows_for_figure.append (new_line_figure)
           
    out_putfile = open (file_path + 'Every_spec_normalized_ratio_for_figure_on_spec_level.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing csv file')
    out_put_csv_file_writing.writerows(write_by_rows_for_figure)
    output_file.close()
    
    ##############################################
    top_n_spectrum_for_peptide_ratio = int(input ('please indicates top N spectrum used for peptide ratio'))
    all_intensity_collection_peptide_level = {}
    all_peptides_collection = []
    for each_scan_number in gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num.keys():
        
        if gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1] not in all_peptides_collection:
            all_peptides_collection.append (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1])
            all_intensity_collection_peptide_level [gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]] = []
            all_intensity_collection_peptide_level [gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]].append([gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1]])
            all_intensity_collection_peptide_level [gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]].append ({each_scan_number:gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1]})
            all_intensity_collection_peptide_level [gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]].append (gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][-1:])
        else:
            all_intensity_collection_peptide_level [gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]][0].append(gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1])
            all_intensity_collection_peptide_level [gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][4][1][2][1]][1][each_scan_number] = gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num[each_scan_number][1]
    
    import heapq
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        all_intensity_collection_peptide_level [each_peptide_seq][0] =heapq.nlargest(top_n_spectrum_for_peptide_ratio,all_intensity_collection_peptide_level [each_peptide_seq][0])
    
    
    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        
        top_n_scan_sum_intensity = [0,0,0,0]
        for each_top_selected_intensity in all_intensity_collection_peptide_level [each_peptide_seq][0]:
            
            top_n_scan_sum_intensity [0]= round((top_n_scan_sum_intensity [0] + each_top_selected_intensity [0]),4)
            top_n_scan_sum_intensity [1]= round((top_n_scan_sum_intensity [1] + each_top_selected_intensity [1]),4)
            top_n_scan_sum_intensity [2]= round((top_n_scan_sum_intensity [2] + each_top_selected_intensity [2]),4)
            top_n_scan_sum_intensity [3]= round((top_n_scan_sum_intensity [3] + each_top_selected_intensity [3]),4)
        if sum(top_n_scan_sum_intensity) != 0:
            normalized_ratio_on_peptide_level = [round ((top_n_scan_sum_intensity [0]/(sum(top_n_scan_sum_intensity)/normalize_number)),2),round ((top_n_scan_sum_intensity [1]/(sum(top_n_scan_sum_intensity)/normalize_number)),2),round ((top_n_scan_sum_intensity [2]/(sum(top_n_scan_sum_intensity)/normalize_number)),2),round ((top_n_scan_sum_intensity [3]/(sum(top_n_scan_sum_intensity)/normalize_number)),2)]
        else:
            normalized_ratio_on_peptide_level = [0,0,0,0]
               
        all_intensity_collection_peptide_level [each_peptide_seq].insert (0,top_n_scan_sum_intensity)
        all_intensity_collection_peptide_level [each_peptide_seq].insert (0,normalized_ratio_on_peptide_level)

    write_by_rows = [['peptide','normalized_ratio_peptide_level','total_intensity_every_channel_peptide_level','total_intensity_all_channels_peptide_level']]

    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        if 0 in all_intensity_collection_peptide_level[each_peptide_seq][0]:
            continue
    
        new_line = [str (each_peptide_seq)]
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1]))
        new_line.append (str (sum (all_intensity_collection_peptide_level[each_peptide_seq][1])))
        
        
        write_by_rows.append (new_line)
       
    
    out_putfile = open (file_path + 'Every_peptide_normalized_ratio_for_quik_check.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()


    write_by_rows = [['peptide','normalized_ratio_peptide_level_plus0','normalized_ratio_peptide_level_plus1','normalized_ratio_peptide_level_plus2','normalized_ratio_peptide_level_plus3','total_intensity_every_channel_peptide_level','total_intensity_all_channels_peptide_level']]

    for each_peptide_seq in all_intensity_collection_peptide_level.keys():
        if 0 in all_intensity_collection_peptide_level[each_peptide_seq][0]:
            continue
    
        new_line = [str (each_peptide_seq)]
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][0]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][1]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][2]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][0][3]))
        new_line.append (str (all_intensity_collection_peptide_level[each_peptide_seq][1]))
        new_line.append (str (sum (all_intensity_collection_peptide_level[each_peptide_seq][1])))
        
        
        write_by_rows.append (new_line)
       
    
    out_putfile = open (file_path + 'Every_peptide_normalized_ratio_for_figure.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()
    #####################################################

    top_n_peptides_for_protein_ratio = int (input ('please indicates top N peptides used for protein ratio'))
    all_intensity_collection_protein_level = {}
    all_protein_accession_collection = []
    for each_peptide_sequence in all_intensity_collection_peptide_level.keys():
        
        temp_related_proteins = all_intensity_collection_peptide_level[each_peptide_sequence][4][0][1][9][1].split(':')
        for each_temp_related_protein in temp_related_proteins:
            if each_temp_related_protein not in all_protein_accession_collection:
                all_protein_accession_collection.append (each_temp_related_protein)
                all_intensity_collection_protein_level [each_temp_related_protein] = []
                all_intensity_collection_protein_level [each_temp_related_protein].append([all_intensity_collection_peptide_level[each_peptide_sequence][1]])
                all_intensity_collection_protein_level [each_temp_related_protein].append ([{each_peptide_sequence:all_intensity_collection_peptide_level[each_peptide_sequence]}])
            else:
                all_intensity_collection_protein_level [each_temp_related_protein][0].append(all_intensity_collection_peptide_level[each_peptide_sequence][1])
                all_intensity_collection_protein_level [each_temp_related_protein][1].append ({each_peptide_sequence:all_intensity_collection_peptide_level[each_peptide_sequence]})
    import heapq
    for each_selected_protein in all_intensity_collection_protein_level.keys():
        all_intensity_collection_protein_level [each_selected_protein][0] =heapq.nlargest(top_n_peptides_for_protein_ratio,all_intensity_collection_protein_level [each_selected_protein][0])
    
    
    for each_selected_protein in all_intensity_collection_protein_level.keys():
        
        top_n_peptide_sum_intensity = [0,0,0,0]
        for each_top_selected_peptide_intensity in all_intensity_collection_protein_level [each_selected_protein][0]:
            
            top_n_peptide_sum_intensity [0]= round((top_n_peptide_sum_intensity [0] + each_top_selected_peptide_intensity [0]),4)
            top_n_peptide_sum_intensity [1]= round((top_n_peptide_sum_intensity [1] + each_top_selected_peptide_intensity [1]),4)
            top_n_peptide_sum_intensity [2]= round((top_n_peptide_sum_intensity [2] + each_top_selected_peptide_intensity [2]),4)
            top_n_peptide_sum_intensity [3]= round((top_n_peptide_sum_intensity [3] + each_top_selected_peptide_intensity [3]),4)
        if sum(top_n_peptide_sum_intensity) != 0:
            normalized_ratio_on_protein_level = [round ((top_n_peptide_sum_intensity [0]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [1]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [2]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2),round ((top_n_peptide_sum_intensity [3]/(sum(top_n_peptide_sum_intensity)/normalize_number)),2)]
        else:
            normalized_ratio_on_protein_level = [0,0,0,0]
               
        all_intensity_collection_protein_level [each_selected_protein].insert (0,top_n_peptide_sum_intensity)
        all_intensity_collection_protein_level [each_selected_protein].insert (0,normalized_ratio_on_protein_level)
    #######################################################
    write_by_rows = [['protein','normalized_ratio_protein_level','total_intensity_every_channel_protein_level','total_intensity_all_channels_protein_level']]

    for each_protein_accession in all_intensity_collection_protein_level.keys():
        if 0 in all_intensity_collection_protein_level[each_protein_accession][0]:
            continue
    
        new_line = [str (each_protein_accession)]
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][0]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][1]))
        new_line.append (str (sum (all_intensity_collection_protein_level[each_protein_accession][1])))
        
        write_by_rows.append (new_line)
        
    out_putfile = open (file_path + 'Every_protein_normalized_ratio_for_quik_check.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Every_protein_normalized_ratio_for_quik_check csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()
    #######################################################
    
    write_by_rows = [['protein','normalized_ratio_protein_level_plus0','normalized_ratio_protein_level_plus1','normalized_ratio_protein_level_plus2','normalized_ratio_protein_level_plus3','total_intensity_every_channel_protein_level','total_intensity_all_channels_protein_level']]

    for each_protein_accession in all_intensity_collection_protein_level.keys():

        if 0 in all_intensity_collection_protein_level[each_protein_accession][0]:
            continue
    
        new_line = [str (each_protein_accession)]
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][0][0]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][0][1]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][0][2]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][0][3]))
        new_line.append (str (all_intensity_collection_protein_level[each_protein_accession][1]))
        new_line.append (str (sum (all_intensity_collection_protein_level[each_protein_accession][1])))
        
        write_by_rows.append (new_line)
        
    out_putfile = open (file_path + 'Every_protein_normalized_ratio_for_figure.csv', 'w', newline = '')
    #creating a output file. the newline=''is to avoid the blank row in the produced csv 
    out_put_csv_file_writing = csv.writer(out_putfile)
    print ('preparing Every_protein_normalized_ratio_for_figure csv file')
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()
    #######################################################
    
    
    
    return gather_ion_name_intense_ratio_sum_intensities_for_all_sacn_num
    


'''test_dict = {6302: [['b1_13C+0', 'S', 349.0705, 1902503.625], ['b1_13C+1', 'S', 350.0739, 1562874.25], ['b1_13C+2', 'S', 351.0773, 753759.8125], ['b1_13C+3', 'S', 352.0807, 1368160.25], ['b2_13C+0', 'SE', 478.1131, 923492.0625], ['b2_13C+1', 'SE', 479.1165, 1314714.25], ['b2_13C+2', 'SE', 480.1199, 995121.625], ['b2_13C+3', 'SE', 481.1233, 845429.625], ['b3_13C+0', 'SEI', 591.1945, '0'], ['b3_13C+1', 'SEI', 592.1979, '0'], ['b3_13C+2', 'SEI', 593.2013, '0'], ['b3_13C+3', 'SEI', 594.2047, '0'], ['b4_13C+0', 'SEIA', 662.2316, '0'], ['b4_13C+1', 'SEIA', 663.235, '0'], ['b4_13C+2', 'SEIA', 664.2384, '0'], ['b4_13C+3', 'SEIA', 665.2418, '0'], ['b5_13C+0', 'SEIAH', 799.2905, '0'], ['b5_13C+1', 'SEIAH', 800.2939, '0'], ['b5_13C+2', 'SEIAH', 801.2973, '0'], ['b5_13C+3', 'SEIAH', 802.3007, '0'], ['b6_13C+0', 'SEIAHR', 955.3916, 240325.2031], ['b6_13C+1', 'SEIAHR', 956.395, 265952.5312], ['b6_13C+2', 'SEIAHR', 957.3984, '0'], ['b6_13C+3', 'SEIAHR', 958.4018, 308347.6562], ['b7_13C+0', 'SEIAHRF', 1102.46, '0'], ['b7_13C+1', 'SEIAHRF', 1103.4634, '0'], ['b7_13C+2', 'SEIAHRF', 1104.4668, '0'], ['b7_13C+3', 'SEIAHRF', 1105.4702, '0'], ['b1_-H2O_13C+0', 'S', 331.0599, 1554115.75], ['b1_-H2O_13C+1', 'S', 332.0633, 1185224.5], ['b1_-H2O_13C+2', 'S', 333.0667, 1092276.0], ['b1_-H2O_13C+3', 'S', 334.0701, 1082826.0], ['b1_-NH3_13C+0', 'S', 332.044, 1185224.5], ['b1_-NH3_13C+1', 'S', 333.0474, 1092276.0], ['b1_-NH3_13C+2', 'S', 334.0508, 1082826.0], ['b1_-NH3_13C+3', 'S', 335.0542, '0'], ['b2_-H2O_13C+0', 'SE', 460.1025, 1563130.625], ['b2_-H2O_13C+1', 'SE', 461.1059, 2031038.375], ['b2_-H2O_13C+2', 'SE', 462.1093, 1456113.5], ['b2_-H2O_13C+3', 'SE', 463.1127, 1470833.125], ['b2_-NH3_13C+0', 'SE', 461.0866, 2031038.375], ['b2_-NH3_13C+1', 'SE', 462.09, 1456113.5], ['b2_-NH3_13C+2', 'SE', 463.0934, 1470833.125], ['b2_-NH3_13C+3', 'SE', 464.0968, '0'], ['b3_-H2O_13C+0', 'SEI', 573.1839, '0'], ['b3_-H2O_13C+1', 'SEI', 574.1873, '0'], ['b3_-H2O_13C+2', 'SEI', 575.1907, '0'], ['b3_-H2O_13C+3', 'SEI', 576.1941, '0'], ['b3_-NH3_13C+0', 'SEI', 574.168, '0'], ['b3_-NH3_13C+1', 'SEI', 575.1714, '0'], ['b3_-NH3_13C+2', 'SEI', 576.1748, '0'], ['b3_-NH3_13C+3', 'SEI', 577.1782, '0'], ['b4_-H2O_13C+0', 'SEIA', 644.221, '0'], ['b4_-H2O_13C+1', 'SEIA', 645.2244, '0'], ['b4_-H2O_13C+2', 'SEIA', 646.2278, '0'], ['b4_-H2O_13C+3', 'SEIA', 647.2312, '0'], ['b4_-NH3_13C+0', 'SEIA', 645.2051, '0'], ['b4_-NH3_13C+1', 'SEIA', 646.2085, '0'], ['b4_-NH3_13C+2', 'SEIA', 647.2119, '0'], ['b4_-NH3_13C+3', 'SEIA', 648.2153, '0'], ['b5_-H2O_13C+0', 'SEIAH', 781.2799, '0'], ['b5_-H2O_13C+1', 'SEIAH', 782.2833, '0'], ['b5_-H2O_13C+2', 'SEIAH', 783.2867, '0'], ['b5_-H2O_13C+3', 'SEIAH', 784.2901, '0'], ['b5_-NH3_13C+0', 'SEIAH', 782.264, '0'], ['b5_-NH3_13C+1', 'SEIAH', 783.2674, '0'], ['b5_-NH3_13C+2', 'SEIAH', 784.2708, '0'], ['b5_-NH3_13C+3', 'SEIAH', 785.2742, '0'], ['b6_-H2O_13C+0', 'SEIAHR', 937.381, '0'], ['b6_-H2O_13C+1', 'SEIAHR', 938.3844, '0'], ['b6_-H2O_13C+2', 'SEIAHR', 939.3878, '0'], ['b6_-H2O_13C+3', 'SEIAHR', 940.3912, '0'], ['b6_-NH3_13C+0', 'SEIAHR', 938.3651, '0'], ['b6_-NH3_13C+1', 'SEIAHR', 939.3685, '0'], ['b6_-NH3_13C+2', 'SEIAHR', 940.3719, '0'], ['b6_-NH3_13C+3', 'SEIAHR', 941.3753, '0'], ['b7_-H2O_13C+0', 'SEIAHRF', 1084.4494, '0'], ['b7_-H2O_13C+1', 'SEIAHRF', 1085.4528, '0'], ['b7_-H2O_13C+2', 'SEIAHRF', 1086.4562, '0'], ['b7_-H2O_13C+3', 'SEIAHRF', 1087.4596, '0'], ['b7_-NH3_13C+0', 'SEIAHRF', 1085.4335, '0'], ['b7_-NH3_13C+1', 'SEIAHRF', 1086.4369, '0'], ['b7_-NH3_13C+2', 'SEIAHRF', 1087.4403, '0'], ['b7_-NH3_13C+3', 'SEIAHRF', 1088.4437, '0'], ['y1_13C+0', 'K', 260.161, 589575.25], ['y1_13C+1', 'K', 261.1644, 304855.3125], ['y1_13C+2', 'K', 262.1678, 558615.875], ['y1_13C+3', 'K', 263.1712, 303316.7188], ['y2_13C+0', 'KF', 407.2294, 624678.125], ['y2_13C+1', 'KF', 408.2328, 349911.875], ['y2_13C+2', 'KF', 409.2362, 677629.625], ['y2_13C+3', 'KF', 410.2396, 849589.8125], ['y3_13C+0', 'KFR', 563.3305, 1533017.5], ['y3_13C+1', 'KFR', 564.3339, 1507670.75], ['y3_13C+2', 'KFR', 565.3373, 1972881.875], ['y3_13C+3', 'KFR', 566.3407, 1339827.5], ['y4_13C+0', 'KFRH', 700.3894, 3417394.5], ['y4_13C+1', 'KFRH', 701.3928, 2721766.25], ['y4_13C+2', 'KFRH', 702.3962, 3689109.0], ['y4_13C+3', 'KFRH', 703.3996, 3383925.5], ['y5_13C+0', 'KFRHA', 771.4265, 5251915.0], ['y5_13C+1', 'KFRHA', 772.4299, 5554512.5], ['y5_13C+2', 'KFRHA', 773.4333, 6313523.0], ['y5_13C+3', 'KFRHA', 774.4367, 6475699.5], ['y6_13C+0', 'KFRHAI', 884.5079, 1271257.375], ['y6_13C+1', 'KFRHAI', 885.5113, 1481627.875], ['y6_13C+2', 'KFRHAI', 886.5147, 2040247.875], ['y6_13C+3', 'KFRHAI', 887.5181, 2084363.25], ['y7_13C+0', 'KFRHAIE', 1013.5505, 949708.1875], ['y7_13C+1', 'KFRHAIE', 1014.5539, 946727.9375], ['y7_13C+2', 'KFRHAIE', 1015.5573, 835570.9375], ['y7_13C+3', 'KFRHAIE', 1016.5607, 1060332.625], ['y1_-H2O_13C+0', 'K', 242.1504, '0'], ['y1_-H2O_13C+1', 'K', 243.1538, 274019.5938], ['y1_-H2O_13C+2', 'K', 244.1572, '0'], ['y1_-H2O_13C+3', 'K', 245.1606, '0'], ['y1_-NH3_13C+0', 'K', 243.1345, 274019.5938], ['y1_-NH3_13C+1', 'K', 244.1379, '0'], ['y1_-NH3_13C+2', 'K', 245.1413, '0'], ['y1_-NH3_13C+3', 'K', 246.1447, '0'], ['y2_-H2O_13C+0', 'KF', 389.2188, '0'], ['y2_-H2O_13C+1', 'KF', 390.2222, '0'], ['y2_-H2O_13C+2', 'KF', 391.2256, '0'], ['y2_-H2O_13C+3', 'KF', 392.229, '0'], ['y2_-NH3_13C+0', 'KF', 390.2029, '0'], ['y2_-NH3_13C+1', 'KF', 391.2063, '0'], ['y2_-NH3_13C+2', 'KF', 392.2097, '0'], ['y2_-NH3_13C+3', 'KF', 393.2131, '0'], ['y3_-H2O_13C+0', 'KFR', 545.3199, '0'], ['y3_-H2O_13C+1', 'KFR', 546.3233, '0'], ['y3_-H2O_13C+2', 'KFR', 547.3267, '0'], ['y3_-H2O_13C+3', 'KFR', 548.3301, '0'], ['y3_-NH3_13C+0', 'KFR', 546.304, '0'], ['y3_-NH3_13C+1', 'KFR', 547.3074, '0'], ['y3_-NH3_13C+2', 'KFR', 548.3108, '0'], ['y3_-NH3_13C+3', 'KFR', 549.3142, '0'], ['y4_-H2O_13C+0', 'KFRH', 682.3788, '0'], ['y4_-H2O_13C+1', 'KFRH', 683.3822, 173730.7969], ['y4_-H2O_13C+2', 'KFRH', 684.3856, '0'], ['y4_-H2O_13C+3', 'KFRH', 685.389, '0'], ['y4_-NH3_13C+0', 'KFRH', 683.3629, 173730.7969], ['y4_-NH3_13C+1', 'KFRH', 684.3663, '0'], ['y4_-NH3_13C+2', 'KFRH', 685.3697, '0'], ['y4_-NH3_13C+3', 'KFRH', 686.3731, '0'], ['y4_2charge_13C+0', 'KFRH', 351.2025, 184259.4219], ['y4_2charge_13C+1', 'KFRH', 352.2059, 897756.875], ['y4_2charge_13C+2', 'KFRH', 353.2093, '0'], ['y4_2charge_13C+3', 'KFRH', 354.2127, '0'], ['y5_-H2O_13C+0', 'KFRHA', 753.4159, '0'], ['y5_-H2O_13C+1', 'KFRHA', 754.4193, '0'], ['y5_-H2O_13C+2', 'KFRHA', 755.4227, 286368.1562], ['y5_-H2O_13C+3', 'KFRHA', 756.4261, '0'], ['y5_-NH3_13C+0', 'KFRHA', 754.4, '0'], ['y5_-NH3_13C+1', 'KFRHA', 755.4034, 286368.1562], ['y5_-NH3_13C+2', 'KFRHA', 756.4068, '0'], ['y5_-NH3_13C+3', 'KFRHA', 757.4102, '0'], ['y5_2charge_13C+0', 'KFRHA', 386.721, 527228.9375], ['y5_2charge_13C+1', 'KFRHA', 387.7244, '0'], ['y5_2charge_13C+2', 'KFRHA', 388.7278, '0'], ['y5_2charge_13C+3', 'KFRHA', 389.7312, '0'], ['y6_-H2O_13C+0', 'KFRHAI', 866.4973, '0'], ['y6_-H2O_13C+1', 'KFRHAI', 867.5007, '0'], ['y6_-H2O_13C+2', 'KFRHAI', 868.5041, '0'], ['y6_-H2O_13C+3', 'KFRHAI', 869.5075, '0'], ['y6_-NH3_13C+0', 'KFRHAI', 867.4814, '0'], ['y6_-NH3_13C+1', 'KFRHAI', 868.4848, '0'], ['y6_-NH3_13C+2', 'KFRHAI', 869.4882, '0'], ['y6_-NH3_13C+3', 'KFRHAI', 870.4916, '0'], ['y6_2charge_13C+0', 'KFRHAI', 443.2618, 311066.1875], ['y6_2charge_13C+1', 'KFRHAI', 444.2652, 626713.6875], ['y6_2charge_13C+2', 'KFRHAI', 445.2686, '0'], ['y6_2charge_13C+3', 'KFRHAI', 446.272, '0'], ['y7_-H2O_13C+0', 'KFRHAIE', 995.5399, '0'], ['y7_-H2O_13C+1', 'KFRHAIE', 996.5433, '0'], ['y7_-H2O_13C+2', 'KFRHAIE', 997.5467, '0'], ['y7_-H2O_13C+3', 'KFRHAIE', 998.5501, 211476.4062], ['y7_-NH3_13C+0', 'KFRHAIE', 996.524, '0'], ['y7_-NH3_13C+1', 'KFRHAIE', 997.5274, '0'], ['y7_-NH3_13C+2', 'KFRHAIE', 998.5308, 211476.4062], ['y7_-NH3_13C+3', 'KFRHAIE', 999.5342, '0'], ['y7_2charge_13C+0', 'KFRHAIE', 507.7831, 353702.7188], ['y7_2charge_13C+1', 'KFRHAIE', 508.7865, 187330.3594], ['y7_2charge_13C+2', 'KFRHAIE', 509.7899, '0'], ['y7_2charge_13C+3', 'KFRHAIE', 510.7933, '0'], ['spectrum_information', [['m_over_z', 682.8141], ['retention_time', 1807.2], ['peptide', 'SEIAHRFK'], ['mass', 1363.6183], ['charge_states', 2], ['logP', 36.75], ['length', 8], ['ppm', -3.4], ['area', '9.4865E8'], ['protein_accession', 'P02769'], ['determining_precursor_selection', 1]]]]}
test_dict_large_peptide = {10207: [['b1_13C+0', 'V', 361.1069, 13087.6943], ['b1_13C+1', 'V', 362.1103, 21945.8418], ['b1_13C+2', 'V', 363.1137, 21232.1758], ['b1_13C+3', 'V', 364.1171, 16652.8828], ['b2_13C+0', 'VP', 458.1597, '0'], ['b2_13C+1', 'VP', 459.1631, '0'], ['b2_13C+2', 'VP', 460.1665, '0'], ['b2_13C+3', 'VP', 461.1699, '0'], ['b3_13C+0', 'VPQ', 586.2183, '0'], ['b3_13C+1', 'VPQ', 587.2217, '0'], ['b3_13C+2', 'VPQ', 588.2251, '0'], ['b3_13C+3', 'VPQ', 589.2285, '0'], ['b4_13C+0', 'VPQV', 685.2867, 4805.5806], ['b4_13C+1', 'VPQV', 686.2901, 7399.875], ['b4_13C+2', 'VPQV', 687.2935, 15587.5352], ['b4_13C+3', 'VPQV', 688.2969, 6060.3892], ['b5_13C+0', 'VPQVS', 772.3187, '0'], ['b5_13C+1', 'VPQVS', 773.3221, '0'], ['b5_13C+2', 'VPQVS', 774.3255, '0'], ['b5_13C+3', 'VPQVS', 775.3289, '0'], ['b6_13C+0', 'VPQVST', 873.3664, '0'], ['b6_13C+1', 'VPQVST', 874.3698, '0'], ['b6_13C+2', 'VPQVST', 875.3732, '0'], ['b6_13C+3', 'VPQVST', 876.3766, '0'], ['b7_13C+0', 'VPQVSTP', 970.4192, '0'], ['b7_13C+1', 'VPQVSTP', 971.4226, '0'], ['b7_13C+2', 'VPQVSTP', 972.426, '0'], ['b7_13C+3', 'VPQVSTP', 973.4294, '0'], ['b8_13C+0', 'VPQVSTPT', 1071.4669, '0'], ['b8_13C+1', 'VPQVSTPT', 1072.4703, '0'], ['b8_13C+2', 'VPQVSTPT', 1073.4737, '0'], ['b8_13C+3', 'VPQVSTPT', 1074.4771, '0'], ['b9_13C+0', 'VPQVSTPTL', 1184.5483, '0'], ['b9_13C+1', 'VPQVSTPTL', 1185.5517, '0'], ['b9_13C+2', 'VPQVSTPTL', 1186.5551, '0'], ['b9_13C+3', 'VPQVSTPTL', 1187.5585, '0'], ['b10_13C+0', 'VPQVSTPTLV', 1283.6167, '0'], ['b10_13C+1', 'VPQVSTPTLV', 1284.6201, '0'], ['b10_13C+2', 'VPQVSTPTLV', 1285.6235, '0'], ['b10_13C+3', 'VPQVSTPTLV', 1286.6269, '0'], ['b11_13C+0', 'VPQVSTPTLVE', 1412.6593, '0'], ['b11_13C+1', 'VPQVSTPTLVE', 1413.6627, '0'], ['b11_13C+2', 'VPQVSTPTLVE', 1414.6661, '0'], ['b11_13C+3', 'VPQVSTPTLVE', 1415.6695, '0'], ['b12_13C+0', 'VPQVSTPTLVEV', 1511.7277, '0'], ['b12_13C+1', 'VPQVSTPTLVEV', 1512.7311, '0'], ['b12_13C+2', 'VPQVSTPTLVEV', 1513.7345, '0'], ['b12_13C+3', 'VPQVSTPTLVEV', 1514.7379, '0'], ['b13_13C+0', 'VPQVSTPTLVEVS', 1598.7597, '0'], ['b13_13C+1', 'VPQVSTPTLVEVS', 1599.7631, '0'], ['b13_13C+2', 'VPQVSTPTLVEVS', 1600.7665, '0'], ['b13_13C+3', 'VPQVSTPTLVEVS', 1601.7699, '0'], ['b14_13C+0', 'VPQVSTPTLVEVSR', 1754.8608, '0'], ['b14_13C+1', 'VPQVSTPTLVEVSR', 1755.8642, '0'], ['b14_13C+2', 'VPQVSTPTLVEVSR', 1756.8676, '0'], ['b14_13C+3', 'VPQVSTPTLVEVSR', 1757.871, '0'], ['b15_13C+0', 'VPQVSTPTLVEVSRS', 1841.8928, '0'], ['b15_13C+1', 'VPQVSTPTLVEVSRS', 1842.8962, '0'], ['b15_13C+2', 'VPQVSTPTLVEVSRS', 1843.8996, '0'], ['b15_13C+3', 'VPQVSTPTLVEVSRS', 1844.903, '0'], ['b16_13C+0', 'VPQVSTPTLVEVSRSL', 1954.9742, '0'], ['b16_13C+1', 'VPQVSTPTLVEVSRSL', 1955.9776, '0'], ['b16_13C+2', 'VPQVSTPTLVEVSRSL', 1956.981, '0'], ['b16_13C+3', 'VPQVSTPTLVEVSRSL', 1957.9844, '0'], ['b17_13C+0', 'VPQVSTPTLVEVSRSLG', 2011.9957, '0'], ['b17_13C+1', 'VPQVSTPTLVEVSRSLG', 2012.9991, '0'], ['b17_13C+2', 'VPQVSTPTLVEVSRSLG', 2014.0025, '0'], ['b17_13C+3', 'VPQVSTPTLVEVSRSLG', 2015.0059, '0'], ['b1_-H2O_13C+0', 'V', 343.0963, '0'], ['b1_-H2O_13C+1', 'V', 344.0997, '0'], ['b1_-H2O_13C+2', 'V', 345.1031, '0'], ['b1_-H2O_13C+3', 'V', 346.1065, '0'], ['b1_-NH3_13C+0', 'V', 344.0804, '0'], ['b1_-NH3_13C+1', 'V', 345.0838, '0'], ['b1_-NH3_13C+2', 'V', 346.0872, '0'], ['b1_-NH3_13C+3', 'V', 347.0906, '0'], ['b2_-H2O_13C+0', 'VP', 440.1491, '0'], ['b2_-H2O_13C+1', 'VP', 441.1525, '0'], ['b2_-H2O_13C+2', 'VP', 442.1559, '0'], ['b2_-H2O_13C+3', 'VP', 443.1593, '0'], ['b2_-NH3_13C+0', 'VP', 441.1332, '0'], ['b2_-NH3_13C+1', 'VP', 442.1366, '0'], ['b2_-NH3_13C+2', 'VP', 443.14, '0'], ['b2_-NH3_13C+3', 'VP', 444.1434, '0'], ['b3_-H2O_13C+0', 'VPQ', 568.2077, '0'], ['b3_-H2O_13C+1', 'VPQ', 569.2111, '0'], ['b3_-H2O_13C+2', 'VPQ', 570.2145, '0'], ['b3_-H2O_13C+3', 'VPQ', 571.2179, '0'], ['b3_-NH3_13C+0', 'VPQ', 569.1918, '0'], ['b3_-NH3_13C+1', 'VPQ', 570.1952, '0'], ['b3_-NH3_13C+2', 'VPQ', 571.1986, '0'], ['b3_-NH3_13C+3', 'VPQ', 572.202, '0'], ['b4_-H2O_13C+0', 'VPQV', 667.2761, '0'], ['b4_-H2O_13C+1', 'VPQV', 668.2795, '0'], ['b4_-H2O_13C+2', 'VPQV', 669.2829, '0'], ['b4_-H2O_13C+3', 'VPQV', 670.2863, '0'], ['b4_-NH3_13C+0', 'VPQV', 668.2602, '0'], ['b4_-NH3_13C+1', 'VPQV', 669.2636, '0'], ['b4_-NH3_13C+2', 'VPQV', 670.267, '0'], ['b4_-NH3_13C+3', 'VPQV', 671.2704, '0'], ['b5_-H2O_13C+0', 'VPQVS', 754.3081, '0'], ['b5_-H2O_13C+1', 'VPQVS', 755.3115, '0'], ['b5_-H2O_13C+2', 'VPQVS', 756.3149, '0'], ['b5_-H2O_13C+3', 'VPQVS', 757.3183, '0'], ['b5_-NH3_13C+0', 'VPQVS', 755.2922, '0'], ['b5_-NH3_13C+1', 'VPQVS', 756.2956, '0'], ['b5_-NH3_13C+2', 'VPQVS', 757.299, '0'], ['b5_-NH3_13C+3', 'VPQVS', 758.3024, '0'], ['b6_-H2O_13C+0', 'VPQVST', 855.3558, '0'], ['b6_-H2O_13C+1', 'VPQVST', 856.3592, '0'], ['b6_-H2O_13C+2', 'VPQVST', 857.3626, '0'], ['b6_-H2O_13C+3', 'VPQVST', 858.366, '0'], ['b6_-NH3_13C+0', 'VPQVST', 856.3399, '0'], ['b6_-NH3_13C+1', 'VPQVST', 857.3433, '0'], ['b6_-NH3_13C+2', 'VPQVST', 858.3467, '0'], ['b6_-NH3_13C+3', 'VPQVST', 859.3501, '0'], ['b7_-H2O_13C+0', 'VPQVSTP', 952.4086, '0'], ['b7_-H2O_13C+1', 'VPQVSTP', 953.412, '0'], ['b7_-H2O_13C+2', 'VPQVSTP', 954.4154, '0'], ['b7_-H2O_13C+3', 'VPQVSTP', 955.4188, '0'], ['b7_-NH3_13C+0', 'VPQVSTP', 953.3927, '0'], ['b7_-NH3_13C+1', 'VPQVSTP', 954.3961, '0'], ['b7_-NH3_13C+2', 'VPQVSTP', 955.3995, '0'], ['b7_-NH3_13C+3', 'VPQVSTP', 956.4029, '0'], ['b8_-H2O_13C+0', 'VPQVSTPT', 1053.4563, '0'], ['b8_-H2O_13C+1', 'VPQVSTPT', 1054.4597, '0'], ['b8_-H2O_13C+2', 'VPQVSTPT', 1055.4631, '0'], ['b8_-H2O_13C+3', 'VPQVSTPT', 1056.4665, '0'], ['b8_-NH3_13C+0', 'VPQVSTPT', 1054.4404, '0'], ['b8_-NH3_13C+1', 'VPQVSTPT', 1055.4438, '0'], ['b8_-NH3_13C+2', 'VPQVSTPT', 1056.4472, '0'], ['b8_-NH3_13C+3', 'VPQVSTPT', 1057.4506, '0'], ['b9_-H2O_13C+0', 'VPQVSTPTL', 1166.5377, '0'], ['b9_-H2O_13C+1', 'VPQVSTPTL', 1167.5411, '0'], ['b9_-H2O_13C+2', 'VPQVSTPTL', 1168.5445, '0'], ['b9_-H2O_13C+3', 'VPQVSTPTL', 1169.5479, '0'], ['b9_-NH3_13C+0', 'VPQVSTPTL', 1167.5218, '0'], ['b9_-NH3_13C+1', 'VPQVSTPTL', 1168.5252, '0'], ['b9_-NH3_13C+2', 'VPQVSTPTL', 1169.5286, '0'], ['b9_-NH3_13C+3', 'VPQVSTPTL', 1170.532, '0'], ['b10_-H2O_13C+0', 'VPQVSTPTLV', 1265.6061, '0'], ['b10_-H2O_13C+1', 'VPQVSTPTLV', 1266.6095, '0'], ['b10_-H2O_13C+2', 'VPQVSTPTLV', 1267.6129, '0'], ['b10_-H2O_13C+3', 'VPQVSTPTLV', 1268.6163, '0'], ['b10_-NH3_13C+0', 'VPQVSTPTLV', 1266.5902, '0'], ['b10_-NH3_13C+1', 'VPQVSTPTLV', 1267.5936, '0'], ['b10_-NH3_13C+2', 'VPQVSTPTLV', 1268.597, '0'], ['b10_-NH3_13C+3', 'VPQVSTPTLV', 1269.6004, '0'], ['b11_-H2O_13C+0', 'VPQVSTPTLVE', 1394.6487, '0'], ['b11_-H2O_13C+1', 'VPQVSTPTLVE', 1395.6521, '0'], ['b11_-H2O_13C+2', 'VPQVSTPTLVE', 1396.6555, '0'], ['b11_-H2O_13C+3', 'VPQVSTPTLVE', 1397.6589, '0'], ['b11_-NH3_13C+0', 'VPQVSTPTLVE', 1395.6328, '0'], ['b11_-NH3_13C+1', 'VPQVSTPTLVE', 1396.6362, '0'], ['b11_-NH3_13C+2', 'VPQVSTPTLVE', 1397.6396, '0'], ['b11_-NH3_13C+3', 'VPQVSTPTLVE', 1398.643, '0'], ['b12_-H2O_13C+0', 'VPQVSTPTLVEV', 1493.7171, '0'], ['b12_-H2O_13C+1', 'VPQVSTPTLVEV', 1494.7205, '0'], ['b12_-H2O_13C+2', 'VPQVSTPTLVEV', 1495.7239, '0'], ['b12_-H2O_13C+3', 'VPQVSTPTLVEV', 1496.7273, '0'], ['b12_-NH3_13C+0', 'VPQVSTPTLVEV', 1494.7012, '0'], ['b12_-NH3_13C+1', 'VPQVSTPTLVEV', 1495.7046, '0'], ['b12_-NH3_13C+2', 'VPQVSTPTLVEV', 1496.708, '0'], ['b12_-NH3_13C+3', 'VPQVSTPTLVEV', 1497.7114, '0'], ['b13_-H2O_13C+0', 'VPQVSTPTLVEVS', 1580.7491, '0'], ['b13_-H2O_13C+1', 'VPQVSTPTLVEVS', 1581.7525, '0'], ['b13_-H2O_13C+2', 'VPQVSTPTLVEVS', 1582.7559, '0'], ['b13_-H2O_13C+3', 'VPQVSTPTLVEVS', 1583.7593, '0'], ['b13_-NH3_13C+0', 'VPQVSTPTLVEVS', 1581.7332, '0'], ['b13_-NH3_13C+1', 'VPQVSTPTLVEVS', 1582.7366, '0'], ['b13_-NH3_13C+2', 'VPQVSTPTLVEVS', 1583.74, '0'], ['b13_-NH3_13C+3', 'VPQVSTPTLVEVS', 1584.7434, '0'], ['b14_-H2O_13C+0', 'VPQVSTPTLVEVSR', 1736.8502, '0'], ['b14_-H2O_13C+1', 'VPQVSTPTLVEVSR', 1737.8536, '0'], ['b14_-H2O_13C+2', 'VPQVSTPTLVEVSR', 1738.857, '0'], ['b14_-H2O_13C+3', 'VPQVSTPTLVEVSR', 1739.8604, '0'], ['b14_-NH3_13C+0', 'VPQVSTPTLVEVSR', 1737.8343, '0'], ['b14_-NH3_13C+1', 'VPQVSTPTLVEVSR', 1738.8377, '0'], ['b14_-NH3_13C+2', 'VPQVSTPTLVEVSR', 1739.8411, '0'], ['b14_-NH3_13C+3', 'VPQVSTPTLVEVSR', 1740.8445, '0'], ['b15_-H2O_13C+0', 'VPQVSTPTLVEVSRS', 1823.8822, '0'], ['b15_-H2O_13C+1', 'VPQVSTPTLVEVSRS', 1824.8856, '0'], ['b15_-H2O_13C+2', 'VPQVSTPTLVEVSRS', 1825.889, '0'], ['b15_-H2O_13C+3', 'VPQVSTPTLVEVSRS', 1826.8924, '0'], ['b15_-NH3_13C+0', 'VPQVSTPTLVEVSRS', 1824.8663, '0'], ['b15_-NH3_13C+1', 'VPQVSTPTLVEVSRS', 1825.8697, '0'], ['b15_-NH3_13C+2', 'VPQVSTPTLVEVSRS', 1826.8731, '0'], ['b15_-NH3_13C+3', 'VPQVSTPTLVEVSRS', 1827.8765, '0'], ['b16_-H2O_13C+0', 'VPQVSTPTLVEVSRSL', 1936.9636, '0'], ['b16_-H2O_13C+1', 'VPQVSTPTLVEVSRSL', 1937.967, '0'], ['b16_-H2O_13C+2', 'VPQVSTPTLVEVSRSL', 1938.9704, '0'], ['b16_-H2O_13C+3', 'VPQVSTPTLVEVSRSL', 1939.9738, '0'], ['b16_-NH3_13C+0', 'VPQVSTPTLVEVSRSL', 1937.9477, '0'], ['b16_-NH3_13C+1', 'VPQVSTPTLVEVSRSL', 1938.9511, '0'], ['b16_-NH3_13C+2', 'VPQVSTPTLVEVSRSL', 1939.9545, '0'], ['b16_-NH3_13C+3', 'VPQVSTPTLVEVSRSL', 1940.9579, '0'], ['b17_-H2O_13C+0', 'VPQVSTPTLVEVSRSLG', 1993.9851, '0'], ['b17_-H2O_13C+1', 'VPQVSTPTLVEVSRSLG', 1994.9885, '0'], ['b17_-H2O_13C+2', 'VPQVSTPTLVEVSRSLG', 1995.9919, '0'], ['b17_-H2O_13C+3', 'VPQVSTPTLVEVSRSLG', 1996.9953, '0'], ['b17_-NH3_13C+0', 'VPQVSTPTLVEVSRSLG', 1994.9692, '0'], ['b17_-NH3_13C+1', 'VPQVSTPTLVEVSRSLG', 1995.9726, '0'], ['b17_-NH3_13C+2', 'VPQVSTPTLVEVSRSLG', 1996.976, '0'], ['b17_-NH3_13C+3', 'VPQVSTPTLVEVSRSLG', 1997.9794, '0'], ['y1_13C+0', 'K', 260.161, '0'], ['y1_13C+1', 'K', 261.1644, 11694.1318], ['y1_13C+2', 'K', 262.1678, 4905.6567], ['y1_13C+3', 'K', 263.1712, 13895.6309], ['y2_13C+0', 'KG', 317.1825, 16681.9453], ['y2_13C+1', 'KG', 318.1859, 41939.4492], ['y2_13C+2', 'KG', 319.1893, 23458.0273], ['y2_13C+3', 'KG', 320.1927, 21697.3418], ['y3_13C+0', 'KGL', 430.2639, '0'], ['y3_13C+1', 'KGL', 431.2673, '0'], ['y3_13C+2', 'KGL', 432.2707, '0'], ['y3_13C+3', 'KGL', 433.2741, '0'], ['y4_13C+0', 'KGLS', 517.2959, '0'], ['y4_13C+1', 'KGLS', 518.2993, '0'], ['y4_13C+2', 'KGLS', 519.3027, 3998.4807], ['y4_13C+3', 'KGLS', 520.3061, '0'], ['y5_13C+0', 'KGLSR', 673.397, 4331.9902], ['y5_13C+1', 'KGLSR', 674.4004, 6385.772], ['y5_13C+2', 'KGLSR', 675.4038, '0'], ['y5_13C+3', 'KGLSR', 676.4072, 5200.7227], ['y6_13C+0', 'KGLSRS', 760.429, 26657.3262], ['y6_13C+1', 'KGLSRS', 761.4324, 34112.4727], ['y6_13C+2', 'KGLSRS', 762.4358, 37904.5039], ['y6_13C+3', 'KGLSRS', 763.4392, 24027.2051], ['y7_13C+0', 'KGLSRSV', 859.4974, 25509.7637], ['y7_13C+1', 'KGLSRSV', 860.5008, 30856.1836], ['y7_13C+2', 'KGLSRSV', 861.5042, 17004.5449], ['y7_13C+3', 'KGLSRSV', 862.5076, 19097.8008], ['y8_13C+0', 'KGLSRSVE', 988.54, 49601.0625], ['y8_13C+1', 'KGLSRSVE', 989.5434, 67411.4922], ['y8_13C+2', 'KGLSRSVE', 990.5468, 63519.5], ['y8_13C+3', 'KGLSRSVE', 991.5502, 44046.3906], ['y9_13C+0', 'KGLSRSVEV', 1087.6084, 32222.416], ['y9_13C+1', 'KGLSRSVEV', 1088.6118, 48088.2812], ['y9_13C+2', 'KGLSRSVEV', 1089.6152, 51348.0898], ['y9_13C+3', 'KGLSRSVEV', 1090.6186, 41149.5469], ['y10_13C+0', 'KGLSRSVEVL', 1200.6898, 13657.7949], ['y10_13C+1', 'KGLSRSVEVL', 1201.6932, 28461.5195], ['y10_13C+2', 'KGLSRSVEVL', 1202.6966, 24588.0547], ['y10_13C+3', 'KGLSRSVEVL', 1203.7, 22244.0938], ['y11_13C+0', 'KGLSRSVEVLT', 1301.7375, '0'], ['y11_13C+1', 'KGLSRSVEVLT', 1302.7409, 12274.5332], ['y11_13C+2', 'KGLSRSVEVLT', 1303.7443, 13767.001], ['y11_13C+3', 'KGLSRSVEVLT', 1304.7477, 5204.5425], ['y12_13C+0', 'KGLSRSVEVLTP', 1398.7903, 189861.1875], ['y12_13C+1', 'KGLSRSVEVLTP', 1399.7937, 288793.9688], ['y12_13C+2', 'KGLSRSVEVLTP', 1400.7971, 288536.4062], ['y12_13C+3', 'KGLSRSVEVLTP', 1401.8005, 221153.9531], ['y13_13C+0', 'KGLSRSVEVLTPT', 1499.838, 31882.5293], ['y13_13C+1', 'KGLSRSVEVLTPT', 1500.8414, 58613.0938], ['y13_13C+2', 'KGLSRSVEVLTPT', 1501.8448, 53148.2852], ['y13_13C+3', 'KGLSRSVEVLTPT', 1502.8482, 34866.707], ['y14_13C+0', 'KGLSRSVEVLTPTS', 1586.87, 69157.6016], ['y14_13C+1', 'KGLSRSVEVLTPTS', 1587.8734, 113566.4609], ['y14_13C+2', 'KGLSRSVEVLTPTS', 1588.8768, 121964.1562], ['y14_13C+3', 'KGLSRSVEVLTPTS', 1589.8802, 92726.9453], ['y15_13C+0', 'KGLSRSVEVLTPTSV', 1685.9384, 23050.1875], ['y15_13C+1', 'KGLSRSVEVLTPTSV', 1686.9418, 32593.0352], ['y15_13C+2', 'KGLSRSVEVLTPTSV', 1687.9452, 45943.5352], ['y15_13C+3', 'KGLSRSVEVLTPTSV', 1688.9486, 31957.9902], ['y16_13C+0', 'KGLSRSVEVLTPTSVQ', 1813.997, '0'], ['y16_13C+1', 'KGLSRSVEVLTPTSVQ', 1815.0004, '0'], ['y16_13C+2', 'KGLSRSVEVLTPTSVQ', 1816.0038, '0'], ['y16_13C+3', 'KGLSRSVEVLTPTSVQ', 1817.0072, '0'], ['y17_13C+0', 'KGLSRSVEVLTPTSVQP', 1911.0498, '0'], ['y17_13C+1', 'KGLSRSVEVLTPTSVQP', 1912.0532, '0'], ['y17_13C+2', 'KGLSRSVEVLTPTSVQP', 1913.0566, '0'], ['y17_13C+3', 'KGLSRSVEVLTPTSVQP', 1914.06, '0'], ['y1_-H2O_13C+0', 'K', 242.1504, '0'], ['y1_-H2O_13C+1', 'K', 243.1538, 6450.7417], ['y1_-H2O_13C+2', 'K', 244.1572, 4828.2559], ['y1_-H2O_13C+3', 'K', 245.1606, '0'], ['y1_-NH3_13C+0', 'K', 243.1345, 6450.7417], ['y1_-NH3_13C+1', 'K', 244.1379, 4828.2559], ['y1_-NH3_13C+2', 'K', 245.1413, '0'], ['y1_-NH3_13C+3', 'K', 246.1447, '0'], ['y2_-H2O_13C+0', 'KG', 299.1719, '0'], ['y2_-H2O_13C+1', 'KG', 300.1753, '0'], ['y2_-H2O_13C+2', 'KG', 301.1787, '0'], ['y2_-H2O_13C+3', 'KG', 302.1821, '0'], ['y2_-NH3_13C+0', 'KG', 300.156, '0'], ['y2_-NH3_13C+1', 'KG', 301.1594, '0'], ['y2_-NH3_13C+2', 'KG', 302.1628, '0'], ['y2_-NH3_13C+3', 'KG', 303.1662, '0'], ['y3_-H2O_13C+0', 'KGL', 412.2533, 121490.5], ['y3_-H2O_13C+1', 'KGL', 413.2567, 5086.7637], ['y3_-H2O_13C+2', 'KGL', 414.2601, '0'], ['y3_-H2O_13C+3', 'KGL', 415.2635, '0'], ['y3_-NH3_13C+0', 'KGL', 413.2374, 5086.7637], ['y3_-NH3_13C+1', 'KGL', 414.2408, 23398.4492], ['y3_-NH3_13C+2', 'KGL', 415.2442, '0'], ['y3_-NH3_13C+3', 'KGL', 416.2476, '0'], ['y4_-H2O_13C+0', 'KGLS', 499.2853, '0'], ['y4_-H2O_13C+1', 'KGLS', 500.2887, '0'], ['y4_-H2O_13C+2', 'KGLS', 501.2921, '0'], ['y4_-H2O_13C+3', 'KGLS', 502.2955, '0'], ['y4_-NH3_13C+0', 'KGLS', 500.2694, '0'], ['y4_-NH3_13C+1', 'KGLS', 501.2728, '0'], ['y4_-NH3_13C+2', 'KGLS', 502.2762, '0'], ['y4_-NH3_13C+3', 'KGLS', 503.2796, '0'], ['y5_-H2O_13C+0', 'KGLSR', 655.3864, '0'], ['y5_-H2O_13C+1', 'KGLSR', 656.3898, '0'], ['y5_-H2O_13C+2', 'KGLSR', 657.3932, '0'], ['y5_-H2O_13C+3', 'KGLSR', 658.3966, '0'], ['y5_-NH3_13C+0', 'KGLSR', 656.3705, '0'], ['y5_-NH3_13C+1', 'KGLSR', 657.3739, '0'], ['y5_-NH3_13C+2', 'KGLSR', 658.3773, '0'], ['y5_-NH3_13C+3', 'KGLSR', 659.3807, '0'], ['y6_-H2O_13C+0', 'KGLSRS', 742.4184, 4632.6943], ['y6_-H2O_13C+1', 'KGLSRS', 743.4218, '0'], ['y6_-H2O_13C+2', 'KGLSRS', 744.4252, '0'], ['y6_-H2O_13C+3', 'KGLSRS', 745.4286, '0'], ['y6_-NH3_13C+0', 'KGLSRS', 743.4025, '0'], ['y6_-NH3_13C+1', 'KGLSRS', 744.4059, '0'], ['y6_-NH3_13C+2', 'KGLSRS', 745.4093, '0'], ['y6_-NH3_13C+3', 'KGLSRS', 746.4127, '0'], ['y7_-H2O_13C+0', 'KGLSRSV', 841.4868, '0'], ['y7_-H2O_13C+1', 'KGLSRSV', 842.4902, '0'], ['y7_-H2O_13C+2', 'KGLSRSV', 843.4936, '0'], ['y7_-H2O_13C+3', 'KGLSRSV', 844.497, 4775.5439], ['y7_-NH3_13C+0', 'KGLSRSV', 842.4709, '0'], ['y7_-NH3_13C+1', 'KGLSRSV', 843.4743, '0'], ['y7_-NH3_13C+2', 'KGLSRSV', 844.4777, 4775.5439], ['y7_-NH3_13C+3', 'KGLSRSV', 845.4811, '0'], ['y8_-H2O_13C+0', 'KGLSRSVE', 970.5294, '0'], ['y8_-H2O_13C+1', 'KGLSRSVE', 971.5328, '0'], ['y8_-H2O_13C+2', 'KGLSRSVE', 972.5362, '0'], ['y8_-H2O_13C+3', 'KGLSRSVE', 973.5396, '0'], ['y8_-NH3_13C+0', 'KGLSRSVE', 971.5135, '0'], ['y8_-NH3_13C+1', 'KGLSRSVE', 972.5169, '0'], ['y8_-NH3_13C+2', 'KGLSRSVE', 973.5203, '0'], ['y8_-NH3_13C+3', 'KGLSRSVE', 974.5237, 6957.2153], ['y9_-H2O_13C+0', 'KGLSRSVEV', 1069.5978, '0'], ['y9_-H2O_13C+1', 'KGLSRSVEV', 1070.6012, 5699.3145], ['y9_-H2O_13C+2', 'KGLSRSVEV', 1071.6046, '0'], ['y9_-H2O_13C+3', 'KGLSRSVEV', 1072.608, '0'], ['y9_-NH3_13C+0', 'KGLSRSVEV', 1070.5819, 5699.3145], ['y9_-NH3_13C+1', 'KGLSRSVEV', 1071.5853, '0'], ['y9_-NH3_13C+2', 'KGLSRSVEV', 1072.5887, '0'], ['y9_-NH3_13C+3', 'KGLSRSVEV', 1073.5921, '0'], ['y10_-H2O_13C+0', 'KGLSRSVEVL', 1182.6792, '0'], ['y10_-H2O_13C+1', 'KGLSRSVEVL', 1183.6826, '0'], ['y10_-H2O_13C+2', 'KGLSRSVEVL', 1184.686, '0'], ['y10_-H2O_13C+3', 'KGLSRSVEVL', 1185.6894, '0'], ['y10_-NH3_13C+0', 'KGLSRSVEVL', 1183.6633, '0'], ['y10_-NH3_13C+1', 'KGLSRSVEVL', 1184.6667, '0'], ['y10_-NH3_13C+2', 'KGLSRSVEVL', 1185.6701, '0'], ['y10_-NH3_13C+3', 'KGLSRSVEVL', 1186.6735, '0'], ['y11_-H2O_13C+0', 'KGLSRSVEVLT', 1283.7269, '0'], ['y11_-H2O_13C+1', 'KGLSRSVEVLT', 1284.7303, '0'], ['y11_-H2O_13C+2', 'KGLSRSVEVLT', 1285.7337, 26551.3184], ['y11_-H2O_13C+3', 'KGLSRSVEVLT', 1286.7371, 12463.8828], ['y11_-NH3_13C+0', 'KGLSRSVEVLT', 1284.711, '0'], ['y11_-NH3_13C+1', 'KGLSRSVEVLT', 1285.7144, 26551.3184], ['y11_-NH3_13C+2', 'KGLSRSVEVLT', 1286.7178, 12463.8828], ['y11_-NH3_13C+3', 'KGLSRSVEVLT', 1287.7212, '0'], ['y12_-H2O_13C+0', 'KGLSRSVEVLTP', 1380.7797, 4155.2627], ['y12_-H2O_13C+1', 'KGLSRSVEVLTP', 1381.7831, 7134.3936], ['y12_-H2O_13C+2', 'KGLSRSVEVLTP', 1382.7865, 5978.8843], ['y12_-H2O_13C+3', 'KGLSRSVEVLTP', 1383.7899, '0'], ['y12_-NH3_13C+0', 'KGLSRSVEVLTP', 1381.7638, 7134.3936], ['y12_-NH3_13C+1', 'KGLSRSVEVLTP', 1382.7672, 5978.8843], ['y12_-NH3_13C+2', 'KGLSRSVEVLTP', 1383.7706, 13106.3242], ['y12_-NH3_13C+3', 'KGLSRSVEVLTP', 1384.774, '0'], ['y13_-H2O_13C+0', 'KGLSRSVEVLTPT', 1481.8274, '0'], ['y13_-H2O_13C+1', 'KGLSRSVEVLTPT', 1482.8308, '0'], ['y13_-H2O_13C+2', 'KGLSRSVEVLTPT', 1483.8342, '0'], ['y13_-H2O_13C+3', 'KGLSRSVEVLTPT', 1484.8376, '0'], ['y13_-NH3_13C+0', 'KGLSRSVEVLTPT', 1482.8115, '0'], ['y13_-NH3_13C+1', 'KGLSRSVEVLTPT', 1483.8149, '0'], ['y13_-NH3_13C+2', 'KGLSRSVEVLTPT', 1484.8183, '0'], ['y13_-NH3_13C+3', 'KGLSRSVEVLTPT', 1485.8217, '0'], ['y14_-H2O_13C+0', 'KGLSRSVEVLTPTS', 1568.8594, '0'], ['y14_-H2O_13C+1', 'KGLSRSVEVLTPTS', 1569.8628, 5645.8013], ['y14_-H2O_13C+2', 'KGLSRSVEVLTPTS', 1570.8662, '0'], ['y14_-H2O_13C+3', 'KGLSRSVEVLTPTS', 1571.8696, '0'], ['y14_-NH3_13C+0', 'KGLSRSVEVLTPTS', 1569.8435, 5645.8013], ['y14_-NH3_13C+1', 'KGLSRSVEVLTPTS', 1570.8469, '0'], ['y14_-NH3_13C+2', 'KGLSRSVEVLTPTS', 1571.8503, '0'], ['y14_-NH3_13C+3', 'KGLSRSVEVLTPTS', 1572.8537, 4799.0034], ['y15_-H2O_13C+0', 'KGLSRSVEVLTPTSV', 1667.9278, '0'], ['y15_-H2O_13C+1', 'KGLSRSVEVLTPTSV', 1668.9312, '0'], ['y15_-H2O_13C+2', 'KGLSRSVEVLTPTSV', 1669.9346, '0'], ['y15_-H2O_13C+3', 'KGLSRSVEVLTPTSV', 1670.938, '0'], ['y15_-NH3_13C+0', 'KGLSRSVEVLTPTSV', 1668.9119, '0'], ['y15_-NH3_13C+1', 'KGLSRSVEVLTPTSV', 1669.9153, '0'], ['y15_-NH3_13C+2', 'KGLSRSVEVLTPTSV', 1670.9187, '0'], ['y15_-NH3_13C+3', 'KGLSRSVEVLTPTSV', 1671.9221, '0'], ['y16_-H2O_13C+0', 'KGLSRSVEVLTPTSVQ', 1795.9864, '0'], ['y16_-H2O_13C+1', 'KGLSRSVEVLTPTSVQ', 1796.9898, '0'], ['y16_-H2O_13C+2', 'KGLSRSVEVLTPTSVQ', 1797.9932, '0'], ['y16_-H2O_13C+3', 'KGLSRSVEVLTPTSVQ', 1798.9966, '0'], ['y16_-NH3_13C+0', 'KGLSRSVEVLTPTSVQ', 1796.9705, '0'], ['y16_-NH3_13C+1', 'KGLSRSVEVLTPTSVQ', 1797.9739, '0'], ['y16_-NH3_13C+2', 'KGLSRSVEVLTPTSVQ', 1798.9773, '0'], ['y16_-NH3_13C+3', 'KGLSRSVEVLTPTSVQ', 1799.9807, '0'], ['y17_-H2O_13C+0', 'KGLSRSVEVLTPTSVQP', 1893.0392, '0'], ['y17_-H2O_13C+1', 'KGLSRSVEVLTPTSVQP', 1894.0426, '0'], ['y17_-H2O_13C+2', 'KGLSRSVEVLTPTSVQP', 1895.046, '0'], ['y17_-H2O_13C+3', 'KGLSRSVEVLTPTSVQP', 1896.0494, '0'], ['y17_-NH3_13C+0', 'KGLSRSVEVLTPTSVQP', 1894.0233, '0'], ['y17_-NH3_13C+1', 'KGLSRSVEVLTPTSVQP', 1895.0267, '0'], ['y17_-NH3_13C+2', 'KGLSRSVEVLTPTSVQP', 1896.0301, '0'], ['y17_-NH3_13C+3', 'KGLSRSVEVLTPTSVQP', 1897.0335, '0'], ['spectrum_information', [['m_over_z', 1137.5837], ['retention_time', 2389.2], ['peptide', 'VPQVSTPTLVEVSRSLGK'], ['mass', 2273.1565], ['charge_states', 2], ['logP', 53.26], ['length', 18], ['ppm', -1.6], ['area', '4.9402E7'], ['protein_accession', 'P02769'], ['determining_precursor_selection', 0]]]]}
working_path = 'G:\\Desktop\\IPTL\\4-plex labeling quantification scripts\\Under writing\\'

simpilified_test_dict = normalize_ratio_for_spec (working_path,test_dict_large_peptide)'''
