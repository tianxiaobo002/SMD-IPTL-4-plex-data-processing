def extract_and_return_uni_pep_list (*file_route_and_file_name):
    print ('preparing list unique peptides ')
    import csv
#importing csv module
    import re
#importing re module for removing the numbers in row of .csv file
    
    space = ''
    unique_peptides = []
    unique_peptides_list = []
    
    for each_protein_peptides_csv_file in file_route_and_file_name:
        file_route = each_protein_peptides_csv_file [0]
        file_name = each_protein_peptides_csv_file [1]
        with open (file_route + file_name) as csvfile:
            reader = csv.DictReader (csvfile)
#calling the csv reader and read the csv file
    
            for row in reader:
                scan_number = row['Scan']
                if scan_number == '':
                    break
                else:
                    peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))[1:-1]
                    unique_peptide = row ['Unique']
                    Accession = row ['Protein Accession']
                    Accession_peptide = [Accession,peptide]
                    
                
                    if Accession_peptide not in unique_peptides and unique_peptide == 'Y':
                        unique_peptides.append (Accession_peptide)
                        unique_peptides_list.append (peptide)
                        
#making the protein_peptide pair at first. Then determining is it unique peptide and is it counted.

    output_file = open (file_route + 'unique_peptides.txt', 'w')
    for pep in unique_peptides:
        output_file.write(str(pep[0])+' '+str(pep[1])+'\n')
    output_file.close()

    
    print ('finish unique peptides ')
    
    return unique_peptides_list

'''def combining_extract_uni_pep (*surpporting_pep_csvs):
    combined_lists = []
    for each_surpporting_pep_csv in surpporting_pep_csvs:
        for every_unique_pep in (extract_and_return_uni_pep_list (each_surpporting_pep_csv [0],each_surpporting_pep_csv [1])):
            if every_unique_pep not in combined_lists:
                combined_lists.append (every_unique_pep)
    return combined_lists'''

'''file_path ='G:\\Desktop\\IPTL\\4-plex labeling quantification scripts\\Under writing\\'
test_file_1 = 'protein-peptides-0-10.csv'
test_file_2 = 'protein-peptides11-20.csv'
test_file_3 = 'protein-peptides11-22.csv'
test_file_4 = 'protein-peptides21-22.csv'

all_uni_peps = combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2])
print ('all_uni_peps',len (all_uni_peps),all_uni_peps)

all_uni_peps_test_derepli = combining_extract_uni_pep ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3])
print ('all_uni_peps_test_derepli',len (all_uni_peps_test_derepli),all_uni_peps_test_derepli)'''

'''all_uni_peps = extract_and_return_uni_pep_list ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_3])
print ('all_uni_peps',len (all_uni_peps),all_uni_peps)

all_uni_peps_test_derepli = extract_and_return_uni_pep_list ([file_path,test_file_1],[file_path,test_file_2],[file_path,test_file_4])
print ('all_uni_peps_test_derepli',len (all_uni_peps_test_derepli),all_uni_peps_test_derepli)'''
