def adding_measured_intensity_to_thero_frag_ions (thero_frag_ions,raw_mgf_dict)

filepath = 'H:\\Users\\Xiaobo Tian\\python data analysis\\for IPTL data moudle June212019\\'

Dict_mgf_raw_peak_list = open (filepath + 'Dict_all_fragment_ion_add_matched_intens.txt', 'r')
txt_to_dict_temp = Dict_mgf_raw_peak_list.read ()
raw_mgf_MS2_spectra_list_add_matched_inten = eval (txt_to_dict_temp)
Dict_mgf_raw_peak_list.close ()

print (raw_mgf_MS2_spectra_list_add_matched_inten [8395])
for i in range (0,(len (raw_mgf_MS2_spectra_list_add_matched_inten [8320])-1)):
    #print (raw_mgf_MS2_spectra_list_add_matched_inten [8395][i][3])
    if float (raw_mgf_MS2_spectra_list_add_matched_inten [8395][i][3]) != 0:
        print (raw_mgf_MS2_spectra_list_add_matched_inten [8395][i])
